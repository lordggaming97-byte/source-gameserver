#pragma once
#include <winsock2.h>
#include <windows.h>
#include <iphlpapi.h>
#include <rpc.h>
#include <cstdio>
#include "LicenseCore.h"
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "Rpcrt4.lib")

namespace LordGamingLicense {
inline std::string ReadHardwareId() {
    DWORD volume = 0;
    if (!GetVolumeInformationA("C:\\", 0, 0, &volume, 0, 0, 0, 0)) return "";
    UUID uuid = {};
    const RPC_STATUS status = UuidCreateSequential(&uuid);
    if (status != RPC_S_OK && status != RPC_S_UUID_LOCAL_ONLY) return "";
    SYSTEM_INFO info = {};
    GetSystemInfo(&info);
    return FormatHardwareId(volume, uuid.Data4 + 2, info.wProcessorArchitecture,
                            info.wProcessorLevel, info.wProcessorRevision);
}
inline bool ReadActiveIPs(std::vector<std::string>& ips) {
    ips.clear();
    ULONG size = 16 * 1024;
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        if (!size || size > 1024 * 1024) return false;
        // ULONG_PTR storage provides the alignment required by the Windows structs.
        std::vector<ULONG_PTR> buffer((size + sizeof(ULONG_PTR) - 1) / sizeof(ULONG_PTR));
        IP_ADAPTER_ADDRESSES* adapters = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(&buffer[0]);
        ULONG status = GetAdaptersAddresses(AF_INET, GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST |
            GAA_FLAG_SKIP_DNS_SERVER, 0, adapters, &size);
        if (status == ERROR_BUFFER_OVERFLOW) continue;
        if (status != NO_ERROR) return false;
        for (IP_ADAPTER_ADDRESSES* a = adapters; a; a = a->Next) {
            if (a->OperStatus != IfOperStatusUp || a->IfType == IF_TYPE_SOFTWARE_LOOPBACK) continue;
            for (IP_ADAPTER_UNICAST_ADDRESS* u = a->FirstUnicastAddress; u; u = u->Next) {
                if (!u->Address.lpSockaddr || u->Address.iSockaddrLength < static_cast<int>(sizeof(sockaddr_in)) ||
                    u->Address.lpSockaddr->sa_family != AF_INET) continue;
                const sockaddr_in* address = reinterpret_cast<const sockaddr_in*>(u->Address.lpSockaddr);
                const unsigned char* b = reinterpret_cast<const unsigned char*>(&address->sin_addr);
                char text[16];
                std::snprintf(text, sizeof(text), "%u.%u.%u.%u", b[0], b[1], b[2], b[3]);
                if (ValidIP(text)) ips.push_back(text);
            }
        }
        return true;
    }
    return false;
}
}
