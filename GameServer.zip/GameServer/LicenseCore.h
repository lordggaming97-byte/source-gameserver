#pragma once
#include <string>
#include <vector>
#include <cstddef>
#include <stdint.h>

namespace LordGamingLicense {
inline std::string Trim(const std::string& value) {
    const std::string whitespace = " \t\r\n";
    const std::size_t first = value.find_first_not_of(whitespace);
    if (first == std::string::npos) return "";
    return value.substr(first, value.find_last_not_of(whitespace) - first + 1);
}
inline bool ValidIP(const std::string& value) {
    std::size_t start = 0;
    unsigned first = 0;
    for (unsigned part = 0; part < 4; ++part) {
        const std::size_t end = value.find('.', start);
        const std::size_t count = (end == std::string::npos ? value.size() : end) - start;
        if (!count || count > 3 || (count > 1 && value[start] == '0')) return false;
        unsigned number = 0;
        for (std::size_t i = start; i < start + count; ++i) {
            if (value[i] < '0' || value[i] > '9') return false;
            number = number * 10 + value[i] - '0';
        }
        if (number > 255) return false;
        if (part == 0) first = number;
        if (part == 3) return end == std::string::npos && first != 0 && first != 127 && first < 224;
        if (end == std::string::npos) return false;
        start = end + 1;
    }
    return false;
}
inline std::string NormalizeHardwareId(const std::string& raw) {
    const std::string value = Trim(raw);
    if (value.size() != 35) return "";
    bool zero = true, ones = true;
    std::string result;
    for (std::size_t i = 0; i < value.size(); ++i) {
        char c = value[i];
        if (i == 8 || i == 17 || i == 26) {
            if (c != '-') return "";
        } else {
            if (c >= 'a' && c <= 'f') c -= 'a' - 'A';
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))) return "";
            zero = zero && c == '0';
            ones = ones && c == 'F';
        }
        result += c;
    }
    return zero || ones ? "" : result;
}
// Same inputs and byte ordering used by the owner's Windows generator.
inline std::string FormatHardwareId(uint32_t volume, const unsigned char node[6],
                                    uint16_t architecture, uint16_t level, uint16_t revision) {
    const uint32_t part[] = {
        volume ^ UINT32_C(0x12B586FE),
        (uint32_t(node[0]) | (uint32_t(node[1]) << 8) | (uint32_t(node[2]) << 16) | (uint32_t(node[3]) << 24)) ^ UINT32_C(0x5D78A569),
        (uint32_t(node[4]) | (uint32_t(node[5]) << 8) | (uint32_t(architecture) << 16)) ^ UINT32_C(0xF45BC123),
        (uint32_t(level) | (uint32_t(revision) << 16)) ^ UINT32_C(0xB542D8E1)
    };
    const char digits[] = "0123456789ABCDEF";
    std::string id;
    for (unsigned group=0; group<4; ++group) {
        if (group) id += '-';
        for (int shift=28; shift>=0; shift-=4) id += digits[(part[group] >> shift) & 15];
    }
    return NormalizeHardwareId(id);
}
inline bool Matches(const std::string& authorizedIP, const std::string& authorizedId,
                    const std::string& configuredIP, const std::string& configuredId,
                    const std::vector<std::string>& activeIPs, const std::string& actualId) {
    const std::string ip = Trim(authorizedIP), id = NormalizeHardwareId(authorizedId);
    if (!ValidIP(ip) || id.empty() || Trim(configuredIP) != ip ||
        NormalizeHardwareId(configuredId) != id || NormalizeHardwareId(actualId) != id) return false;
    for (std::size_t i = 0; i < activeIPs.size(); ++i) if (activeIPs[i] == ip) return true;
    return false;
}
}
