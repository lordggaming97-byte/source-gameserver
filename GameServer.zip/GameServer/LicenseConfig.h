#pragma once

// Compile a separate executable for each authorized VPS.
#define LORDGAMING_LICENSE_IP "164.163.10.53"
// Run the owner's GetHardwareId.exe on the target VPS and copy its HardwareId below.
// An empty value intentionally prevents the GameServer from starting.
#define LORDGAMING_LICENSE_HARDWARE_ID "3E8A0315-064FCE8B-F45BA935-9845D8E7"
